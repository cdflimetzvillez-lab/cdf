import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import MenuButton from '@/components/MenuButton';
import RetourHaut from '@/components/RetourHaut';
import Marquee from '@/components/Marquee';
import Footer from '@/components/Footer';
import RoueRentree from '@/components/roue/RoueRentree';
import BandeauPartenaires from '@/components/BandeauPartenaires';
import { configRoue, getWheelConfig, roueVisible } from '@/lib/roue/db';
import { getThemes } from '@/lib/theme/db';
import { themeDuJour, variablesTheme } from '@/lib/theme/types';
import { BlocTheme, Neige, PastilleTheme } from '@/components/theme/ThemeAccueil';
import { dateCourte, dateLongue, horaires, periode, texteSur } from '@/lib/format';
import type { Partenaire, SiteSettings, Stat, Evenement } from '@/lib/types';

export const revalidate = 60;

export default async function Home() {
  const supabase = await createClient();

  const [{ data: settings }, { data: stats }, { data: evenements }, wheelConfig, { data: partenaires }, { data: tdn }, { data: pn }, themes] = await Promise.all([
    supabase.from('site_settings').select('*').eq('id', 1).single(),
    supabase.from('stats').select('*').order('position'),
    supabase.from('evenements').select('*').eq('publie', true).order('position'),
    getWheelConfig(),
    supabase.from('partenaires').select('*').eq('actif', true).order('position'),
    supabase.from('tdn_reglages').select('module_actif').eq('id', 1).maybeSingle(),
    supabase.from('pn_reglages').select('module_actif').eq('id', 1).maybeSingle(),
    getThemes(),
  ]);
  // Module événementiel : rendu côté serveur uniquement si actif et dans la période.
  const showWheel = roueVisible(wheelConfig);

  const s = settings as SiteSettings;
  const evts = (evenements ?? []) as Evenement[];

  // Places restantes : uniquement pour les événements où l'admin a coché l'affichage (et avec une jauge).
  const restantes = new Map<string, number>();
  await Promise.all(
    evts
      .filter((e) => e.afficher_places_restantes && e.billetterie_active && e.places_max)
      .map(async (e) => {
        const { data } = await supabase.rpc('places_restantes', { evt_id: e.id });
        if (typeof data === 'number') restantes.set(e.id, data);
      }),
  );

  // Thème du moment (Octobre Rose, Noël...) : actif et dans sa période, sinon rien ne change.
  const theme = themeDuJour(themes);
  const styleTheme = theme ? (variablesTheme(theme) as React.CSSProperties) : undefined;
  const annonces = evts.map((e) => `${dateCourte(e.date_debut)} · ${e.titre}`);

  return (
    <>
      <MenuButton tresors={tdn?.module_actif === true} pereNoel={pn?.module_actif === true} />
      <RetourHaut />

      <header className={`hero${theme ? ' th' : ''}`} style={styleTheme ?? { ['--evt' as string]: s.hero_couleur }}>
        {theme && <Neige theme={theme} />}
        <div className="hero-inner">
          <div className="logo-badge">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              className="hero-logo"
              src={s.logo_url || '/logo-cdf.png'}
              alt="Comité des Fêtes de Limetz-Villez"
            />
          </div>
          {theme && <PastilleTheme theme={theme} />}
          <div style={{ marginBottom: '2.4rem' }}>
            <span className="kicker mono">{theme?.etiquette || s.hero_kicker}</span>
          </div>
          <h1>
            {s.hero_titre_1} <span className="jaune">{s.hero_titre_accent}</span>
            <br />
            <span className="cyan">{s.hero_titre_2}</span>
          </h1>
          <p className="hero-tag">{s.hero_texte}</p>
          <div className="hero-cta">
            <a className="btn btn-y" href="#evenements">Voir le programme</a>
            <a className="btn btn-w" href="#benevoles">Devenir bénévole</a>
          </div>
        </div>

        <a className="scroll-hint" href="#evenements">
          <span>Faire défiler</span>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"
               strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="M6 9l6 6 6-6" />
          </svg>
        </a>
      </header>

      {theme ? (
        <>
          <div className="th-bandeau" style={styleTheme}>
            <Marquee items={theme.bandeau ? [theme.bandeau, ...annonces] : annonces} />
          </div>
          <BlocTheme theme={theme} style={styleTheme} />
        </>
      ) : (
        <Marquee items={annonces} />
      )}

      {showWheel && <RoueRentree config={configRoue(wheelConfig)} />}

      <section id="evenements">
        <div className="wrap">
          <div className="head">
            <h2>Le programme</h2>
            <p>Nos rendez-vous de l&apos;année. Cliquez pour les horaires, le lieu et les inscriptions.</p>
          </div>
          <div className="grid">
            {evts.map((e, i) => {
              const fg = texteSur(e.couleur);
              return (
                <Link
                  key={e.id}
                  href={`/evenements/${e.slug}`}
                  className={`poster${fg === '#FFF8EC' ? ' dark' : ''}`}
                  style={{ background: e.couleur, color: fg }}
                >
                  <span className="num">{String(i + 1).padStart(2, '0')}</span>
                  <div>
                    <div className="when">
                      {periode(e.date_debut, e.date_fin)}{horaires(e.heure_debut, e.heure_fin) && ` · ${horaires(e.heure_debut, e.heure_fin)}`}
                    </div>
                    <h3>{e.titre}</h3>
                    <p>{e.chapo}</p>
                  </div>
                  <div className="poster-foot">
                    <span className="price">{e.tarif}</span>
                    {restantes.has(e.id) && (
                      restantes.get(e.id)! <= 0
                        ? <span className="reste complet">Complet</span>
                        : <span className="reste">Plus que {restantes.get(e.id)} place{restantes.get(e.id)! > 1 ? 's' : ''}</span>
                    )}
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
        <BandeauPartenaires partenaires={(partenaires ?? []) as Partenaire[]} />
      </section>

      <section className="about" id="association">
        <div className="wrap">
          <div className="head"><h2>{s.asso_titre}</h2></div>
          <div className="about-grid">
            <div>
              {s.asso_texte.split('\n\n').map((p, i) => <p key={i}>{p}</p>)}
            </div>
            <div className="stats">
              {(stats as Stat[] ?? []).map((st) => (
                <div className="stat" key={st.id}>
                  <b>{st.valeur}</b>
                  <span>{st.libelle}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="join" id="benevoles">
        <div className="mono" style={{ marginBottom: '1rem' }}>On a besoin de bras</div>
        <h2>{s.benevoles_titre}</h2>
        <p>{s.benevoles_texte}</p>
        <a className="btn btn-y" href={`mailto:${s.email_contact}`}>Nous contacter</a>
      </section>

      <Footer settings={s} evenements={evts} />
    </>
  );
}
